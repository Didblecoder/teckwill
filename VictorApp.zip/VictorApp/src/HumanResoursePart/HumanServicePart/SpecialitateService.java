/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HumanResoursePart.HumanServicePart;

import HumanResoursePart.Specialitate;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Asus
 */
public class SpecialitateService {

    public SpecialitateService() {

    }

    public static List<Specialitate> listOfSpecialitati = new ArrayList<Specialitate>() {
        {
            add(new Specialitate("Programist"));
            add(new Specialitate("Manager"));
            add(new Specialitate("Curier"));
            add(new Specialitate("Contabil"));

        }

    };

    public static List AddSpecialitateToList(Specialitate e) {

        listOfSpecialitati.add(e);
        return listOfSpecialitati;

    }

    public static List ShowTheListSpe() {

        return listOfSpecialitati;
    }

}
