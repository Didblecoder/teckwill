/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HumanResoursePart.HumanServicePart;

import HumanResoursePart.Employee;
import java.util.ArrayList;
import HumanResoursePart.HumanServicePart.DataBase;
import static HumanResoursePart.HumanServicePart.DataBase.listTest;
import HumanResoursePart.Specialitate;
import Vissible.HumanResurseArrayApp.MainViewPannel;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.stream.JsonReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Array;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author Asus
 */
public class EmployeeService {

    public ArrayList ShowList() {

        return listTest;
    }

    public static ArrayList AddToList(Employee e) {
        listTest.add(e);
        return listTest;

    }

    public static ArrayList RemoveFromList(int index) {
        listTest.remove(index);
        return listTest;
    }

    public static ArrayList EditEmployee(int index, Employee e) {
        listTest.remove(index);
        listTest.add(index, e);
        return listTest;
    }

    public static ArrayList DeleteAllFromList() {
        listTest.clear();
        return listTest;
    }

    public static ArrayList ReadFromTextFile() {

        String fileName = "C:\\Users\\Asus\\Documents\\NetBeansProjects\\java-swing-tutorial-master\\src\\HumanResoursePart\\HumanServicePart\\fileForTest.txt";
        String line;

        try {
            BufferedReader input = new BufferedReader(new FileReader(fileName));

            if (!input.ready()) {
                throw new IOException();
            }
            while ((line = input.readLine()) != null) {

                String[] b = line.split(" ");

                listTest.add(new Employee(b[0], b[1], b[2], new Specialitate(b[3]))); //aici trebuie sa vie un Employee
            }
            input.close();
        } catch (IOException e) {
            System.out.println(e);
        }
        return listTest;

    }

    public static void ExportArrayListToTextFile() {
        String fileName = "C:\\Users\\Asus\\Documents\\NetBeansProjects\\java-swing-tutorial-master\\src\\HumanResoursePart\\HumanServicePart\\fileForTest.txt";
        try {
            BufferedWriter outPut = new BufferedWriter(new FileWriter(fileName));

            int size = listTest.size();

            for (int i = 0; i < size; i++) {
                outPut.write(listTest.get(i).toString() + "\n");

            }
            outPut.close();

        } catch (IOException ex) {
            System.out.println(ex);
        }

    }

    public static void ExportArrayListToJson() {

        try {
            FileWriter fileWriter = new FileWriter("C:\\Users\\Asus\\Documents\\NetBeansProjects\\java-swing-tutorial-master\\src\\HumanResoursePart\\HumanServicePart\\employeeList.json");
            fileWriter.write("[");
            for (int i = 0; i < listTest.size(); i++) {
                String json = new Gson().toJson(listTest.get(i));

                fileWriter.write(json);
                if (i != (listTest.size() - 1)) {
                    fileWriter.write(",");
                    fileWriter.write("\n");
                }
            }
            fileWriter.write("]");

            fileWriter.close();

        } catch (IOException ex) {
            System.out.println(ex);
        }

//        System.out.println(json);
    }

    public static ArrayList ReadFromJsonFile() {

        JSONParser parser = new JSONParser();

        try {
            JSONArray array = (JSONArray) parser.parse(new FileReader("C:\\Users\\Asus\\Documents\\NetBeansProjects\\java-swing-tutorial-master\\src\\HumanResoursePart\\HumanServicePart\\employeeList.json"));

            for (Object o : array) {
                JSONObject employee = (JSONObject) o;

                String nume = (String) employee.get("nume");
                String prenume = (String) employee.get("prenume");
                String dataNasteri = (String) employee.get("dataNasteri");

                JSONObject spec = (JSONObject) employee.get("specialitate");
                String specialitate = (String) spec.get("name");
                //  System.out.println(specialitate);
                
                listTest.add(new Employee(nume, prenume, dataNasteri, new Specialitate (specialitate)));
            }

        } catch (FileNotFoundException ex) {
            Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ParseException ex) {
            Logger.getLogger(EmployeeService.class.getName()).log(Level.SEVERE, null, ex);
        }

        return listTest;
    }

    public static void Showlist() {
        for (Employee employee : listTest) {
            System.out.println(employee);

        }

    }

    public static void NewLine() {
        System.out.println("\n");

    }

}
