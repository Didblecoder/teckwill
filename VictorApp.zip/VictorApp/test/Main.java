import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
 
public class Main {
    public static void main(String[] args) {
        
    // Convert JSON Array String into Java Array List
     String jsonArrayString = "[\"Russian\",\"English\",\"French\"]";
     Gson googleJson = new Gson();
     ArrayList javaArrayListFromGSON = googleJson.fromJson(jsonArrayString, ArrayList.class);
     
     System.out.println(javaArrayListFromGSON);
       
    }
}