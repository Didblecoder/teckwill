/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HumanResoursePart;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Asus
 */
public class Specialitate {

   
    
    
     public static void main(String[] args){
    Specialitate Medic = null;
   Specialitate Contabil = null;
   Specialitate Manager = null;
   
   
   
    
    
    ArrayList<Specialitate> listOfType = new ArrayList<>();
    
    
    listOfType.add(0,Medic);
    listOfType.add(1,Contabil);
    listOfType.add(2,Manager);
    
    
    
   
    
       //Specialitate spe = new Specialitate();
       
       System.out.println(listOfType.toString());
        
    
    }
    
}
