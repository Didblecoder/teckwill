/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HumanResoursePart;

import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class Employee {

    String nume;
    String prenume;
    String dataNasteri;
    String specialitate;

    public Employee(String nume, String prenume, String dataNasteri, String specialitate) {
        this.nume = nume;
        this.prenume = prenume;
        this.dataNasteri = dataNasteri;
        this.specialitate = specialitate;

    }

    public Employee() {
    }
    ArrayList<Employee> list = new ArrayList<>();

    public ArrayList ListEmployees() {
        // ArrayList<Employee> list = new ArrayList<>();

        Employee u7 = new Employee("as", "Ana", "laasdasdad", "as");

// Employee u7 = new Employee(getNume(), getPrenume(), getDataNasteri(), getSpecialitate());
        // Employee u7 = new Employee(nume, prenume  , dataNasteri, specialitate);
//        User u1 = new User(1, "Ana", "la", 2);
//        User u2 = new User(1, "Ana", "la", 2);
//        User u3 = new User(1, "Ana", "la", 2);
//        User u4 = new User(1, "Ana", "la", 2);
//        User u5 = new User(1, "Ana", "la", 2);
//        User u6 = new User(1, "Ana", "la", 2);
//        list.add(u1);
//        list.add(u2);
//        list.add(u3);
//        list.add(u4);
//        list.add(u5);
//        list.add(u6);
        list.add(u7);

        return list;
    }

    public ArrayList ListEmployees(Employee e) {
        list.add(e);
        return list;

    }

    public String getNume() {
        return nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public String getDataNasteri() {
        return dataNasteri;
    }

    public String getSpecialitate() {
        return specialitate;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public void setDataNasteri(String dataNasteri) {
        this.dataNasteri = dataNasteri;
    }

    public void setSpecialitate(String specialitate) {
        this.specialitate = specialitate;
    }

//    setNume(nume);
//
//    setPrenume(prenume);
//
//    setDataNasteri(dataNasteri);
//
//    setSpecialitate(specialitate);
//    
}
