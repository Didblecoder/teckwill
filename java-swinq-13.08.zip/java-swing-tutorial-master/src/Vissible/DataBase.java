/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Vissible;

import HumanResoursePart.Employee;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class DataBase {

    ArrayList empList = new ArrayList();
   

    public void addToList() {
        Employee emp1 = new Employee("Vic", "Donos", "020201990", "Curier");
        Employee emp2 = new Employee("Dan", "Dan", "020201990", "programist");
//        Employee emp3 = new Employee(nume, prenume, dataNasteri, specialitate)
        empList.add(emp1);
        //empList.add(emp2);
     
    }

    
    
}
