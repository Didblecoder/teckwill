/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HumanResoursePart.HumanServicePart;

import HumanResoursePart.Employee;
import java.util.ArrayList;

/**
 *
 * @author Dell
 */
public class DataBase {

   static  ArrayList<Employee> listTest = new ArrayList<>();
   

   
     
    }

    
    

