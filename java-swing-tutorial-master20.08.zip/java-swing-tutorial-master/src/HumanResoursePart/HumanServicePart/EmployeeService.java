/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HumanResoursePart.HumanServicePart;

import HumanResoursePart.Employee;
import java.util.ArrayList;
import HumanResoursePart.HumanServicePart.DataBase;
import static HumanResoursePart.HumanServicePart.DataBase.listTest;

/**
 *
 * @author Asus
 */
public class EmployeeService {
    
    
    
    
     public ArrayList ShowList() {
        
        return listTest;
    }

    public  static  ArrayList AddToList(Employee e) {
        listTest.add(e);
        return listTest;

    }
    
    public static ArrayList EditEmployee(Employee e){
      // listTest.
    return listTest;
    }
    
}
