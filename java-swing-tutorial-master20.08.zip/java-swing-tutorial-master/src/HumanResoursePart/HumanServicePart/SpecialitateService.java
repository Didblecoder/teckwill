/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HumanResoursePart.HumanServicePart;

import HumanResoursePart.Specialitate;
import java.util.ArrayList;

/**
 *
 * @author Asus
 */
public class SpecialitateService {
    
//    static  ArrayList<Specialitate> listOfSpecialitati = new ArrayList<>();
//    
//    public static ArrayList AddSpecialitati(){
//    
//    listOfSpecialitati.add(new Specialitate("Programist"));
//    listOfSpecialitati.add(new Specialitate("Manager"));
//    listOfSpecialitati.add(new Specialitate("Curier"));
//    listOfSpecialitati.add(new Specialitate("Contabil"));
//    return listOfSpecialitati;
//    }
//    
    
}
